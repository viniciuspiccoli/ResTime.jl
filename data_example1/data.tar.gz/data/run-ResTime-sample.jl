## example 01
# Ubiquitin in a 1.50 mol /L  EMIMDCA solution

using ResTime, PDBTools, Plots, LaTeXStrings

run(`gmx editconf -f sample-groMD.gro -o sample-groMD.pdb`)

solute  = "protein"
atoms   = PDBTools.readPDB("sample-groMD.pdb") # selection - all atoms of the PDB file.

#protein selection
sel0    = PDBTools.select(atoms,solute)        # Selection of which atoms from the PDB are the protein atoms.
protein = ResTime.Selection(sel0, nmols=1)  # Selection for the calculation of time-correlation function / nmols = 1 (one protein)

# anion selection
sel1    = PDBTools.select(atoms,"name N3A and resname NC") 
anion   = ResTime.Selection(sel1,natomspermol=1)     # natomspermol = 1 - selection of 1 atom for each molecule 

# cation selection
sel2    = PDBTools.select(atoms,"name LP and resname EMI")
cation  = ResTime.Selection(sel2,natomspermol=1)     # natomspermol = 1 - selection of 1 atom for each molecule

# water selection
sel3    = PDBTools.select(atoms,"name OW and resname SOL")
water   = ResTime.Selection(sel3,natomspermol=1)     # natomspermol = 1 - selection of 1 atom for each molecule
 
cutoff = 3.5 # cutoff based on MDDFs

# time-correlation calculation for DCA
trajectory = ResTime.Trajectory("sample-groMD.xtc", protein, anion, format="XTC")
time_an, prob_an = correlation(trajectory,cutoff)

# time-correlation calculation for EMIM
trajectory = ResTime.Trajectory("sample-groMD.xtc", protein, cation, format="XTC")
time_cat, prob_cat = correlation(trajectory,cutoff)

# time-correlation calculation for WATER
trajectory = ResTime.Trajectory("sample-groMD.xtc", protein, water, format="XTC")
time_wat, prob_wat = correlation(trajectory,cutoff)

if time_an ≈ time_cat && time_an ≈  time_wat && time_cat ≈ time_wat
  println("esta tudo ok!")
end

# Print the result in a file
ResTime.writefile("EMIMDCA","1.50",time_an, prob_an, prob_cat, prob_wat)

#### plot
plot_font = "Computer Modern"
default(fontfamily=plot_font, linewidth=2, framestyle=:box, label=nothing, grid=false)
fs=12
gr(dpi=600)
plot(legend=:best,grid=:false,framestyle=:box,xtickfontsize=fs,ytickfontsize=fs,xguidefontsize=fs,yguidefontsize=fs,legendfontsize=fs)
plot!(xlabel=L"dt / \textrm{ns}", xlims=[0,2.0],  ylabel=L"\textrm{Time-Correlation\ function}")
plot!(time_an, prob_wat, label=L"\mathrm{H_{2}O}", linewidth=2, color="blue"   )
plot!(time_an, prob_cat, label=L"\mathrm{EMIM}",   linewidth=2, color="gray"   )
plot!(time_an, prob_an , label=L"\mathrm{DCA}",    linewidth=2, color="green"  )
savefig("./time_corr_functions.pdf")
  

